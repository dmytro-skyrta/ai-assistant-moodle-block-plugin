
<?php
defined('MOODLE_INTERNAL') || die();

$plugin->component = 'block_virtualteacher';
$plugin->version = 2025041300;
$plugin->requires = 2022112800;
