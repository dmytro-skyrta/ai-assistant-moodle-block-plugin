<?php
$string['pluginname'] = 'Virtueller Lehrer';
$string['virtualteacher:addinstance'] = 'Add a new virtual teacher block';
$string['virtualteacher:myaddinstance'] = 'Add a new virtual teacher block to My Moodle';